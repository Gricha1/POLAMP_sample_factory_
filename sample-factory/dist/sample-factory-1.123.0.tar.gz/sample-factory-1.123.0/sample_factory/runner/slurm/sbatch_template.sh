#!/bin/bash
conda activate sample-factory
cd ~/sample-factory
