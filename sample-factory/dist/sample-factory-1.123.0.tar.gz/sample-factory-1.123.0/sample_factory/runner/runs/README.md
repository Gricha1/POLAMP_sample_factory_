This is a collection of scripts for various experiments conducted throughout the development of SampleFactory.
Most of the command lines will be obsolete, since the parameter names etc. changed significantly between versions.

Still, it should be relatively easy to modify most of them to work with the latest version. 