### Miscellaneous notes

#### Installing VizDoom in a Conda environment

```
conda install -c conda-forge boost cmake gtk2 sdl2
```
Then install from sources:
- clone repo
- `python setup.py build && python setup.py install`
